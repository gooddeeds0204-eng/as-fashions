# AS FASHIONS — Complete Website Foundation

This project is a responsive fashion e-commerce website foundation.

## Included
- Premium responsive homepage
- Mega-style category navigation
- Product listing, filters and sorting
- Product details with size selection
- Wishlist
- Cart and quantity management
- Login/register/OTP demo flow
- Checkout and address form
- Payment method selection (demo)
- Order confirmation
- Orders and tracking
- Returns/help pages
- Basic admin dashboard
- LocalStorage-based demo persistence
- 38 demo products across the requested fashion categories

## Important
This is a front-end/demo implementation. Real OTP, payment gateway, database, inventory synchronization, shipping APIs, email/SMS notifications and secure admin authentication require a backend and provider credentials.

## Run
Open `index.html` in a browser or use a local static server.
