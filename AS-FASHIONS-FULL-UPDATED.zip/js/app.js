(() => {
const get=(k,d)=>JSON.parse(localStorage.getItem(k)||JSON.stringify(d));
const set=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
window.asGet=get;window.asSet=set;
window.toast=(m)=>{const e=document.getElementById("toast");if(!e)return;e.textContent=m;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2200)};
window.money=n=>"₹"+Number(n).toLocaleString("en-IN");
window.cart=get("as_cart",[]);
window.wishlist=get("as_wishlist",[]);
window.updateCounts=()=>{document.querySelectorAll("#cartCount").forEach(e=>e.textContent=window.cart.reduce((a,x)=>a+x.qty,0));document.querySelectorAll("#wishlistCount").forEach(e=>e.textContent=window.wishlist.length)};
window.addToCart=(id,size=null,color=null)=>{
 const p=PRODUCTS.find(x=>x.id===id);if(!p)return;
 const s=size||p.size, c=color||p.color;
 const found=window.cart.find(x=>x.id===id&&x.size===s&&x.color===c);
 if(found)found.qty++;else window.cart.push({id,size:s,color:c,qty:1});
 set("as_cart",window.cart);updateCounts();toast("Added to bag");
};
window.toggleWishlist=id=>{const i=window.wishlist.indexOf(id);if(i>=0){window.wishlist.splice(i,1);toast("Removed from wishlist")}else{window.wishlist.push(id);toast("Added to wishlist")}set("as_wishlist",window.wishlist);updateCounts();renderAllCards()};
window.card=p=>`<article class="product-card"><div class="product-img"><button class="wish" onclick="toggleWishlist('${p.id}')">${window.wishlist.includes(p.id)?"♥":"♡"}</button><a href="product.html?id=${p.id}"><img src="${p.image}" alt="${p.name}" loading="lazy"><span class="sale-tag">${p.discount}% OFF</span></a></div><div class="product-info"><div class="product-brand">${p.brand}</div><div class="product-name">${p.name}</div><span class="rating">★ ${p.rating}</span><div class="price">${money(p.price)} <span class="mrp">${money(p.mrp)}</span><span class="discount">${p.discount}%</span></div><button class="add-btn" onclick="addToCart('${p.id}')">ADD TO BAG</button></div></article>`;
window.renderAllCards=()=>document.querySelectorAll("[data-card-container]").forEach(()=>{});
function initNav(){
 const nav=document.getElementById("desktopNav"), mobile=document.getElementById("mobileNav");
 const items=CATEGORIES.slice(0,8);
 if(nav)nav.innerHTML=items.map(c=>`<a href="category.html?cat=${c.id}">${c.name}</a>`).join("");
 if(mobile)mobile.innerHTML=items.map(c=>`<a href="category.html?cat=${c.id}">${c.name}</a>`).join("")+`<a href="login.html">Account</a>`;
}
function init(){
 initNav();updateCounts();
 const cg=document.getElementById("categoryGrid");
 if(cg)cg.innerHTML=CATEGORIES.slice(0,8).map(c=>`<a class="category-card" href="category.html?cat=${c.id}"><div class="category-image">${c.icon}</div><strong>${c.name}</strong></a>`).join("");
 const np=document.getElementById("newProducts"),bp=document.getElementById("bestProducts");
 if(np)np.innerHTML=PRODUCTS.filter(p=>p.tag==="new").slice(0,8).map(card).join("");
 if(bp)bp.innerHTML=PRODUCTS.filter(p=>p.tag==="best").slice(0,8).map(card).join("");
 document.querySelectorAll("[data-category]").forEach(b=>b.addEventListener("click",()=>location.href=`category.html?cat=${b.dataset.category}`));
 document.querySelectorAll("[data-filter]").forEach(b=>b.addEventListener("click",()=>location.href=`category.html?filter=${b.dataset.filter}`));
 const searchToggle=document.getElementById("searchToggle"), panel=document.querySelector(".search-panel");
 if(searchToggle)searchToggle.onclick=()=>panel.classList.toggle("open");
 const input=document.getElementById("searchInput"),btn=document.getElementById("searchButton");
 const go=()=>{const q=input.value.trim();if(q)location.href=`category.html?q=${encodeURIComponent(q)}`};
 if(btn)btn.onclick=go;if(input)input.addEventListener("keydown",e=>{if(e.key==="Enter")go()});
 const mb=document.getElementById("mobileMenuBtn"),drawer=document.getElementById("mobileDrawer"),ov=document.getElementById("drawerOverlay");
 const close=()=>{drawer?.classList.remove("open");ov?.classList.remove("open")};
 mb?.addEventListener("click",()=>{drawer.classList.add("open");ov.classList.add("open")});
 document.getElementById("closeDrawer")?.addEventListener("click",close);ov?.addEventListener("click",close);
 document.getElementById("wishlistBtn")?.addEventListener("click",()=>location.href="wishlist.html");
 document.getElementById("cartBtn")?.addEventListener("click",()=>location.href="cart.html");
 document.getElementById("accountBtn")?.addEventListener("click",()=>location.href="login.html");
 const end=Date.now()+1000*60*60*8;
 const tick=()=>{let s=Math.max(0,Math.floor((end-Date.now())/1000));const h=String(Math.floor(s/3600)).padStart(2,"0"),m=String(Math.floor(s%3600/60)).padStart(2,"0"),x=String(s%60).padStart(2,"0");document.querySelectorAll("#saleCountdown,#topCountdown").forEach(e=>e.textContent=`${h}:${m}:${x}`)};tick();setInterval(tick,1000);
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();