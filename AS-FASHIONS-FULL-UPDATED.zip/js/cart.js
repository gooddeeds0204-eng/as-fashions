(() => {
function render(){
 const box=document.getElementById("cartItems"),sum=document.getElementById("cartSummary");
 if(!cart.length){box.innerHTML=`<div class="empty"><h2>Your bag is empty</h2><p>Add products to continue.</p><a class="primary-btn" href="index.html">SHOP NOW</a></div>`;sum.innerHTML="";return}
 let total=0;box.innerHTML=cart.map((x,i)=>{const p=PRODUCTS.find(p=>p.id===x.id);const t=p.price*x.qty;total+=t;return `<div class="cart-row"><img src="${p.image}" alt="${p.name}"><div><strong>${p.brand}</strong><h3>${p.name}</h3><p>Size: ${x.size} · Color: ${x.color}</p><div class="qty"><button onclick="changeQty(${i},-1)">−</button><span>${x.qty}</span><button onclick="changeQty(${i},1)">+</button></div><button class="text-btn" onclick="removeItem(${i})">Remove</button></div><div class="cart-price"><strong>${money(t)}</strong><br><span class="mrp">${money(p.mrp*x.qty)}</span></div></div>`}).join("");
 sum.innerHTML=`<h2>Price Details</h2><div class="summary-row"><span>Subtotal</span><span>${money(total)}</span></div><div class="summary-row"><span>Delivery</span><span>${total>=999?"FREE":money(99)}</span></div><div class="summary-row"><span>Discount</span><span>-${money(Math.max(0,cart.reduce((a,x)=>a+(PRODUCTS.find(p=>p.id===x.id).mrp-PRODUCTS.find(p=>p.id===x.id).price)*x.qty,0)))}</span></div><div class="summary-row summary-total"><span>Total</span><span>${money(total+(total>=999?0:99))}</span></div><button class="primary-btn full" onclick="location.href='checkout.html'">PROCEED TO CHECKOUT</button>`;
}
window.changeQty=(i,d)=>{cart[i].qty+=d;if(cart[i].qty<=0)cart.splice(i,1);asSet("as_cart",cart);updateCounts();render()};
window.removeItem=i=>{cart.splice(i,1);asSet("as_cart",cart);updateCounts();render()};
render();
})();