window.CATEGORIES=[
{id:"men",name:"Men",icon:"👔",subs:["T-Shirts","Shirts","Jeans","Trousers","Shorts","Jackets","Hoodies","Ethnic Wear","Sneakers","Casual Shoes","Formal Shoes","Sports Shoes","Watches","Belts","Wallets","Caps","Sunglasses","Bags"]},
{id:"women",name:"Women",icon:"👗",subs:["Dresses","Tops","T-Shirts","Shirts","Jeans","Trousers","Skirts","Shorts","Kurtis","Sarees","Heels","Flats","Sneakers","Boots","Sandals","Handbags","Backpacks","Watches","Sunglasses","Jewellery"]},
{id:"kids",name:"Kids",icon:"🧒",subs:["Boys Clothing","Girls Clothing","Baby Clothing","Kids Footwear","School Wear","Party Wear","Accessories"]},
{id:"footwear",name:"Footwear",icon:"👟",subs:["Sneakers","Running Shoes","Sports Shoes","Casual Shoes","Formal Shoes","Heels","Flats","Boots","Sandals","Slippers"]},
{id:"bags",name:"Bags",icon:"👜",subs:["Backpacks","Handbags","Sling Bags","Tote Bags","Laptop Bags","Travel Bags","Wallets"]},
{id:"accessories",name:"Accessories",icon:"🕶️",subs:["Watches","Sunglasses","Belts","Caps","Wallets","Jewellery","Hair Accessories","Scarves"]},
{id:"sports",name:"Sports",icon:"🏃",subs:["Sportswear","Running","Training","Gym","Cricket","Football","Basketball","Sports Shoes","Sports Accessories"]},
{id:"winter",name:"Winter Wear",icon:"🧥",subs:["Jackets","Sweaters","Hoodies","Sweatshirts","Thermals","Winter Accessories"]},
{id:"new",name:"New Arrivals",icon:"✨",subs:[]},
{id:"trending",name:"Trending",icon:"🔥",subs:[]}
];