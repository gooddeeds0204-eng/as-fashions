(() => {
if(!cart.length){location.href="cart.html";return}
let total=cart.reduce((a,x)=>a+PRODUCTS.find(p=>p.id===x.id).price*x.qty,0),delivery=total>=999?0:99;
document.getElementById("checkoutSummary").innerHTML=`<h2>Order Summary</h2>${cart.map(x=>{const p=PRODUCTS.find(p=>p.id===x.id);return `<div class="summary-row"><span>${p.name} × ${x.qty}</span><span>${money(p.price*x.qty)}</span></div>`}).join("")}<div class="summary-row"><span>Delivery</span><span>${delivery?money(delivery):"FREE"}</span></div><div class="summary-row summary-total"><span>Total</span><span>${money(total+delivery)}</span></div><button class="primary-btn full" id="placeOrder">PLACE ORDER</button>`;
document.getElementById("addressForm").addEventListener("submit",e=>{e.preventDefault();document.getElementById("placeOrder").click()});
document.getElementById("placeOrder").onclick=()=>{
 const order={id:"ASF"+Date.now().toString().slice(-8),items:cart,total:total+delivery,delivery:"3–6 business days",status:"Order Placed",created:new Date().toISOString(),address:{name:fullName.value,phone:phone.value,pin:pin.value,city:city.value,state:state.value,house:house.value},payment:document.querySelector('input[name="payment"]:checked').value};
 const orders=JSON.parse(localStorage.getItem("as_orders")||"[]");orders.unshift(order);localStorage.setItem("as_orders",JSON.stringify(orders));localStorage.setItem("as_last_order",JSON.stringify(order));localStorage.setItem("as_cart","[]");location.href="order-success.html";
};
})();