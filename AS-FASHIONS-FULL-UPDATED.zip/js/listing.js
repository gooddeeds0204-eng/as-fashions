(() => {
const params=new URLSearchParams(location.search);let current=[...PRODUCTS];
const cat=params.get("cat"),q=(params.get("q")||"").toLowerCase(),filter=params.get("filter");
if(cat&&cat!=="all")current=current.filter(p=>p.category===cat);
if(q)current=current.filter(p=>`${p.name} ${p.gender} ${p.subcategory} ${p.brand}`.toLowerCase().includes(q));
if(filter==="new")current=current.filter(p=>p.tag==="new");
if(filter==="best")current=current.filter(p=>p.tag==="best");
if(cat==="sale")current=current.filter(p=>p.discount>=45);
const title=document.getElementById("listingTitle");title.textContent=cat&&cat!=="all"?(CATEGORIES.find(x=>x.id===cat)?.name||cat):q?`Search: ${q}`:filter?({new:"New Arrivals",best:"Best Sellers"}[filter]||"Sale"):"All Products";
const cf=document.getElementById("categoryFilter");cf.innerHTML=`<option value="">All</option>`+CATEGORIES.map(c=>`<option value="${c.id}">${c.name}</option>`).join("");if(cat)cf.value=cat;
function render(){let a=[...current],s=document.getElementById("sortSelect").value,g=document.getElementById("genderFilter").value,pr=document.getElementById("priceFilter").value,sz=document.getElementById("sizeFilter").value;if(g)a=a.filter(p=>p.gender===g);if(pr){let [x,y]=pr.split("-").map(Number);a=a.filter(p=>p.price>=x&&p.price<=y)}if(sz)a=a.filter(p=>p.size===sz||p.subcategory.toLowerCase().includes(sz.toLowerCase()));if(s==="low")a.sort((x,y)=>x.price-y.price);if(s==="high")a.sort((x,y)=>y.price-x.price);if(s==="discount")a.sort((x,y)=>y.discount-x.discount);if(s==="rating")a.sort((x,y)=>y.rating-x.rating);document.getElementById("listingGrid").innerHTML=a.length?a.map(card).join(""):`<div class="empty"><h2>No products found</h2><p>Try changing your filters.</p></div>`;document.getElementById("resultCount").textContent=`${a.length} products`;}
["sortSelect","categoryFilter","genderFilter","priceFilter","sizeFilter"].forEach(id=>document.getElementById(id).addEventListener("change",e=>{if(id==="categoryFilter"&&e.target.value)location.href=`category.html?cat=${e.target.value}`;else render()}));
document.getElementById("clearFilters").onclick=()=>location.href=cat?`category.html?cat=${cat}`:"category.html";render();
})();