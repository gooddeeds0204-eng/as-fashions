Place icons image files here (referenced by name in js/*.js and index.html).
